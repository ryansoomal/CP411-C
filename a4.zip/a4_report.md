# A4 Report

Author: Ryan Soomal

Date: 2024-11-07 

Check [readme.txt](readme.txt) for course work statement and self-evaluation. 
  
## Q1 Culling, Lighting, Shading (description)


### Q1.1 Concepts of culling

Difference Between Culling and Clipping:

Culling: A process where entire objects or faces that are not visible to the camera (e.g., facing away from the view or outside the view volume) are removed from the rendering pipeline before any further processing. Culling improves efficiency by discarding unnecessary elements early.
Clipping: A process that discards only portions of objects or faces that extend beyond the view volume boundaries. Unlike culling, which removes entire objects, clipping preserves visible parts and discards only those that lie outside the view boundaries.

Difference Between Object Precision and Image Precision in Hidden Surface Removal:

Object Precision: In this approach, visibility is determined based on geometric properties before the rendering step. It operates directly on the 3D model data, calculating the visibility of entire polygons. Example: The Painter’s Algorithm, where polygons are sorted by depth, and farther objects are drawn first.
Image Precision: Visibility is determined at the pixel level during rendering. Each pixel’s depth is computed to handle visibility in screen space, making it suitable for complex, detailed scenes. Example: The Z-buffer algorithm, where each pixel’s depth value is compared and stored to resolve visibility.



### Q1.2 Culling computing

Copy the question and write your answer here.
![alt text](a4q1.2.png){width=90%}

### Q1.3 Concepts of lighting and shading

What does a color model do? Give the names of three color models.
Define how colors are represented in a system.
Examples: RGB (Red-Green-Blue), CMYK (Cyan-Magenta-Yellow-Black), HSV (Hue-Saturation-Value).

What does a light source model determine? Give the names of three light source models.
Describe the origin and characteristics of light in a scene.
Examples: Point light, Directional light, Ambient light.

What does a reflection model determine? Give the names of three reflection models.
Define how surfaces reflect light based on material properties.
Examples: Phong reflection model, Lambertian reflection model, Blinn-Phong reflection model.

What does a shading model determine? Give the names of three shading models.
Describe the methods to apply lighting and reflection calculations to an object’s surface.
Examples: Flat shading, Gouraud shading, Phong shading.

### Q1.4 Lighting computing

Copy the question and write your answer here.
![alt text](a4q1.4.png){width=90%}


## Q2 OpenGL Culling, Lighting, Shading (lab practice)


### Q2.1 Hidden surface removal 

Complete? Yes or No 

<!--If you answer Yes, insert one or more screenshot images to show the completion.-->

![alt text](a4q2.1.png){width=90%}
![alt text](a4q2.1.b.png){width=90%}
<!-- If No, add a short description to describe the issues encountered.-->

### Q2.2 Lighting and shading 

Complete? Yes or No 

<!--If you answer Yes, insert one or more screenshot images to show the completion.-->

![alt text](a4q2.2.png){width=90%}
<!-- If No, add a short description to describe the issues encountered.-->

### Q2.3 Animation 

Complete? Yes or No 

<!--If you answer Yes, insert one or more screenshot images to show the completion.-->

![alt text](a4q2.3.png){width=90%}

<!-- If No, add a short description to describe the issues encountered.-->


## Q3 SimpleView2 Culling, Lighting, Shading (programming)


### Q3.1 Culling

Complete? Yes or No 

<!--If you answer Yes, insert one or more screenshot images to show the completion. -->

![alt text](a4q3.1.png){width=90%}

<!--If No, add a short description to describe the issues encountered.-->


### Q3.2 Lighting

Complete? Yes or No 

<!--If you answer Yes, insert one or more screenshot images to show the completion. -->

![alt text](a4q3.2.png){width=90%}

<!--If No, add a short description to describe the issues encountered.-->


### Q3.3 Shading

Complete? Yes or No 

<!--If you answer Yes, insert one or more screenshot images to show the completion. -->

![alt text](a4q3.3.png){width=90%}

<!--If No, add a short description to describe the issues encountered.-->


### Q3.4 Animations

Complete? Yes or No 

<!--If you answer Yes, insert one or more screenshot images to show the completion. -->

![alt text](a4q3.4.png){width=90%}

<!--If No, add a short description to describe the issues encountered.-->




**References**

1. CP411 a4
2. Add your references if you used any. 
