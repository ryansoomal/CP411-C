/*
 *  SimpleView : reference design
 *  Author: HBF
 *  Version: 2022-10-03 (update)
 */
#include "Light.hpp"
#include "Matrix.hpp"
#include <stdio.h>

Light::Light() {
	mc.mat[0][3] = 2.0;
	mc.mat[1][3] = 2.0;
	mc.mat[2][3] = 2.0;

	I = 1.0;
	Rd = 1.0;
	on = true;
	size = 0.2;

	// Initialize position
	position[0] = 2.0f;  // x-coordinate
	position[1] = 2.0f;  // y-coordinate
	position[2] = 2.0f;  // z-coordinate

}

void Light::Reset() {
	I = 1.0;
	Rd = 1.0;
	on = true;
	size = 30;
}

void Light::Increment(GLfloat p) {
	I += p;  // Adjust the light intensity by p
	if (I < 0.0f) {
		I = 0.0f;  // Ensure intensity doesn't go below 0
	} else if (I > 1.0f) {
		I = 1.0f;  // Cap intensity at a maximum of 1
	}

}

void Light::draw() {
	if (on == true) {
		glPushMatrix();
		this->ctmMultiply();
		glutSolidSphere(size, 10, 10);
		glPopMatrix();
	}
}

