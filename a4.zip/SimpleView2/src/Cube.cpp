/*
 *  SimpleView : reference design
 *  Author: HBF
 *  Version: 2022-10-03 (update)
 */
#include "Cube.hpp"
#include "Camera.hpp"
#include <stdio.h>
#include <GL/glut.h>

extern Camera myCamera;
extern Light myLight;
extern CullMode cullMode;
extern RenderMode renderMode;

Cube::Cube() {
	vertex[0][0] = -1;
	vertex[0][1] = -1;
	vertex[0][2] = -1;
	vertex[1][0] = -1;
	vertex[1][1] = 1;
	vertex[1][2] = -1;
	vertex[2][0] = 1;
	vertex[2][1] = 1;
	vertex[2][2] = -1;
	vertex[3][0] = 1;
	vertex[3][1] = -1;
	vertex[3][2] = -1;
	vertex[4][0] = -1;
	vertex[4][1] = -1;
	vertex[4][2] = 1;
	vertex[5][0] = -1;
	vertex[5][1] = 1;
	vertex[5][2] = 1;
	vertex[6][0] = 1;
	vertex[6][1] = 1;
	vertex[6][2] = 1;
	vertex[7][0] = 1;
	vertex[7][1] = -1;
	vertex[7][2] = 1;

	face[0][0] = 0;
	face[0][1] = 1;
	face[0][2] = 2;
	face[0][3] = 3;
	face[1][0] = 7;
	face[1][1] = 6;
	face[1][2] = 5;
	face[1][3] = 4;
	face[2][0] = 0;
	face[2][1] = 4;
	face[2][2] = 5;
	face[2][3] = 1;
	face[3][0] = 2;
	face[3][1] = 1;
	face[3][2] = 5;
	face[3][3] = 6;
	face[4][0] = 3;
	face[4][1] = 2;
	face[4][2] = 6;
	face[4][3] = 7;
	face[5][0] = 0;
	face[5][1] = 3;
	face[5][2] = 7;
	face[5][3] = 4;

	// faceColor
	faceColor[0][0] = 1.0, faceColor[0][1] = 0.0;
	faceColor[0][2] = 0.0;
	// more

	// set or compute face normals
	faceNormal[0][0] = 0.0, faceNormal[0][1] = 0.0, faceNormal[0][2] = -1.0,
	// more

	// vertex color
	vertexColor[0][0] = 1.0, vertexColor[0][1] = 0.0;
	vertexColor[0][2] = 0.0;
	// more

	// vertex normal
	vertexNormal[0][0] = -1;
	vertexNormal[0][1] = -1;
	vertexNormal[0][2] = -1;
	// more

	r = 1.0;
	g = 0.0;
	b = 0.0;
}

void Cube::drawFace(int i) {
	GLfloat shade = 1;
	switch (renderMode) {
	case WIRE:
		glColor3f(r, g, b);
		glBegin(GL_LINE_LOOP);
		for (int j = 0; j < 4; j++) {
			glVertex3fv(vertex[face[i][j]]);
		}
		glEnd();
		break;
	case CONSTANT:
		if (myLight.on == true)
			shade = getFaceShade(i, myLight);
		glColor3f(faceColor[i][0] * shade, faceColor[i][1] * shade,
				faceColor[i][2] * shade);
		glBegin(GL_POLYGON);
		for (int j = 0; j < 4; j++) {
			glVertex3fv(vertex[face[i][j]]);
		}
		glEnd();
		break;
	case FLAT:

	case SMOOTH:

		break;

	}
}

void Cube::draw() {
	glPushMatrix();
	this->ctmMultiply();
	glScalef(s, s, s);

	for (int i = 0; i < 6; i++) {
		if (cullMode == BACKFACE) {
			if (isFrontface(i, myCamera)) {
				drawFace(i);
			}
		} else {
			drawFace(i);
		}
	}

	glPopMatrix();
}

bool Cube::isFrontface(int faceindex, Camera camera) {
	// Retrieve the normal vector of the specified face
	Vector faceNormalVec(faceNormal[faceindex][0], faceNormal[faceindex][1],
			faceNormal[faceindex][2]);

	// Calculate the approximate center position of the face using the first vertex
	Vector faceCenter(vertex[face[faceindex][0]][0],
			vertex[face[faceindex][0]][1], vertex[face[faceindex][0]][2]);

	// Use the camera's eye position directly as a vector
	Vector cameraPosition(camera.eye.x, camera.eye.y, camera.eye.z);

	// Calculate the view vector from the face center to the camera position
	Vector viewVector(cameraPosition.x - faceCenter.x,
			cameraPosition.y - faceCenter.y, cameraPosition.z - faceCenter.z);

	// Calculate the dot product between the face normal and the view vector
	float dotProduct = faceNormalVec.dot(viewVector);

	// If the dot product is less than 0, the face is front-facing
	return dotProduct < 0;
}

GLfloat Cube::getFaceShade(int faceindex, Light light) {
	GLfloat shade = 1, v[4], s[4], temp;
	// Retrieve the normal of the face
	GLfloat faceNormalX = faceNormal[faceindex][0];
	GLfloat faceNormalY = faceNormal[faceindex][1];
	GLfloat faceNormalZ = faceNormal[faceindex][2];

	// Get light position
	GLfloat lightX = light.position[0];  // Assuming Light has a position array
	GLfloat lightY = light.position[1];
	GLfloat lightZ = light.position[2];

	// Calculate a point on the face (using the first vertex of the face)
	int vertexIndex = face[faceindex][0];
	GLfloat faceX = vertex[vertexIndex][0];
	GLfloat faceY = vertex[vertexIndex][1];
	GLfloat faceZ = vertex[vertexIndex][2];

	// Calculate light vector
	GLfloat lightVectorX = lightX - faceX;
	GLfloat lightVectorY = lightY - faceY;
	GLfloat lightVectorZ = lightZ - faceZ;

	// Normalize the light vector
	GLfloat magnitude = sqrt(
			lightVectorX * lightVectorX + lightVectorY * lightVectorY
					+ lightVectorZ * lightVectorZ);
	if (magnitude > 0) {
		lightVectorX /= magnitude;
		lightVectorY /= magnitude;
		lightVectorZ /= magnitude;
	}

	// Dot product between face normal and light vector
	GLfloat dotProduct = faceNormalX * lightVectorX + faceNormalY * lightVectorY
			+ faceNormalZ * lightVectorZ;

	// Calculate shade based on diffuse reflection model
	GLfloat diffusionRate = 0.5f;  // Diffuse reflection coefficient
	shade = diffusionRate * light.size * std::max(dotProduct, 0.0f);

	return shade;
}

GLfloat Cube::getVertexShade(int i, Light light) {
	GLfloat shade = 1, v[4], s[4], temp;
	GLfloat diffusionRate = 0.5f;  // Diffuse reflection coefficient

	return shade;
}

