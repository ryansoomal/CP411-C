#include "World.hpp"
#include "Cube.hpp"
#include "Pyramid.hpp"
#include "House.hpp"
#include <GL/glut.h>

using namespace std;

World::World() {
	Shape *obj = NULL;

	/* add Cube into the world object list */
	obj = new Cube();
	obj->setId(1);
	obj->scaleChange(-0.2);
	objlist.push_back(obj);

	obj = new Pyramid();
	obj->setId(2);
	obj->scaleChange(-0.2);
	obj->translate(-2.5, 0, 0);
	objlist.push_back(obj);

	obj = new House();
	obj->setId(3);
	obj->scaleChange(-0.2);
	obj->translate(2.5, 0, 0);
	objlist.push_back(obj);
}

World::~World() {
	Shape *obj;
	while (!objlist.empty()) {
		obj = objlist.front();
		objlist.pop_front();
		free(obj);
	}
}

void lineSegment(float x1, float y1, float z1, float x2, float y2, float z2) {
	glBegin(GL_LINES);
	glVertex3f(x1, y1, z1);
	glVertex3f(x2, y2, z2);
	glEnd();
}

void World::draw() {
	glColor3f(1.0, 0.0, 0.0);
	lineSegment(-2, 0, 0, 4, 0, 0); /* x-axis in red */
	glColor3f(0.0, 1.0, 0.0);
	lineSegment(0, -2, 0, 0, 4, 0); /* y-axis in green */
	glColor3f(0.0, 0.0, 1.0);
	lineSegment(0, 0, -2, 0, 0, 4); /* z-axis in blue */

	std::list<Shape*>::iterator it;
	for (it = objlist.begin(); it != objlist.end(); ++it) {
		(*it)->draw();
	}
}

void World::reset() {
	Shape *obj = NULL;

	obj = this->searchById(1);
	obj->reset();
	obj->setScale(0.5);
	obj->translate(2.5, 0, 0);

	obj = this->searchById(2);
	obj->reset();
	obj->setScale(0.5);
	obj->translate(4, 0, 0);

	obj = this->searchById(3);
	obj->reset();
	obj->setScale(0.5);

}

Shape* World::searchById(GLint i) {
	std::list<Shape*>::iterator it;
	for (it = objlist.begin(); it != objlist.end(); ++it) {
		if ((*it)->getId() == i)
			return *it;
	}
	return NULL;
}

void World::animateSingleObject() {
	// Find a specific object to animate, e.g., object with ID 1
	Shape *obj = searchById(1); // Assume object with ID 1 is selected for single object animation

	if (obj != nullptr) {
		// Rotate the selected object around its own z-axis
		obj->rotate(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f); // Rotate by 1 degree around z-axis
	}
	glutPostRedisplay();
}

void World::animateMultipleObjects() {
	// Use specific IDs for objects in a solar system setup
	Shape *sun = searchById(3);   // Assume "House" is the sun with ID 3
	Shape *earth = searchById(1); // Assume "Cube" is the earth with ID 1
	Shape *moon = searchById(2);  // Assume "Pyramid" is the moon with ID 2

	// Rotate the "sun" (House) around its own axis
	if (sun != nullptr) {
		sun->rotate(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.5f); // Rotate by 0.5 degrees around z-axis
	}

	// Rotate "earth" (Cube) around its own axis and orbit around the "sun"
	if (earth != nullptr) {
		// Earth's rotation around its own axis
		earth->rotate(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f); // Rotate by 1 degree around its own z-axis
		// Earth's orbit around the "sun"
		earth->rotateOrigin(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.5f); // Orbit around sun by 0.5 degrees
	}

	// Rotate "moon" (Pyramid) around its own axis and orbit around the "earth"
	if (moon != nullptr) {
		// Moon's rotation around its own axis
		moon->rotate(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.5f); // Rotate by 1.5 degrees around its own z-axis
		// Moon's orbit around the "earth"
		if (earth != nullptr) {
			moon->rotateOrigin(earth->getMC().mat[0][3],
					earth->getMC().mat[1][3], earth->getMC().mat[2][3], 0.0f,
					0.0f, 1.0f, 1.0f);  // Orbit around earth by 1 degree
		}
	}

	glutPostRedisplay();
}

