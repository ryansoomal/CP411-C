JobID: cp411-a3
Name: Ryan Soomal
ID: 210370340

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

A3

Q1 Transformations in CG
Q1.1 [5/5/*] Principle of CG transformations         
Q1.2 [5/5/*] Hand on 2D transformations              

Q2 CG transformation programming
Q2.1 [2/2/*] Warm up with C++                        
Q2.2 [2/2/*] 2D transformations                      
Q2.3 [3/3/*] 3D objects and transformations          
Q2.4 [3/3/*] Mesh object model                       

Q3 SimpleView1 - transformations
Q3.1 [10/10/*] Create and render cube objects          
Q3.2 [10/10/*] Create and render pyramid object        
Q3.3 [10/10/*] Create and render house object          
Q3.4 [20/20/*] MCS transforms                          
Q3.5 [15/15/*] WCS transforms                          
Q3.6 [15/15/*] VCS transforms                          

Total: [100/100/*]
