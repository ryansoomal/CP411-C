/*
 -------------------------------------
 File:    House.hpp
 Project: SimpleView1_reference_design
 file description
 -------------------------------------
 Author:  Ryan Soomal
 ID:      210370340
 Email:   soom0340@mylaurier.ca
 Version  2024-10-25
 -------------------------------------
 */
#ifndef HOUSE_HPP
#define HOUSE_HPP

#include "Shape.hpp"
#include "Cube.hpp"
#include "Pyramid.hpp"

class House: public Shape {
private:
	Cube *base;       // Cube as the base of the house
	Pyramid *roof;    // Pyramid as the roof of the house

public:
	House();
	~House();
	void draw();      // Draws the house by drawing the base and roof
};

#endif
