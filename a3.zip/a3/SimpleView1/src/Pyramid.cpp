/*
 -------------------------------------
 File:    Pyramid.cpp
 Project: SimpleView1_reference_design
 file description
 -------------------------------------
 Author:  Ryan Soomal
 ID:      210370340
 Email:   soom0340@mylaurier.ca
 Version  2024-10-25
 -------------------------------------
 */

#include "Pyramid.hpp"

Pyramid::Pyramid() {
	// Define the 5 vertices of the pyramid (example values)
	vertex[0][0] = 0.0;
	vertex[0][1] = 1.0;
	vertex[0][2] = 0.0;  // Apex
	vertex[1][0] = -1.0;
	vertex[1][1] = 0.0;
	vertex[1][2] = 1.0; // Base front-left
	vertex[2][0] = 1.0;
	vertex[2][1] = 0.0;
	vertex[2][2] = 1.0; // Base front-right
	vertex[3][0] = 1.0;
	vertex[3][1] = 0.0;
	vertex[3][2] = -1.0; // Base back-right
	vertex[4][0] = -1.0;
	vertex[4][1] = 0.0;
	vertex[4][2] = -1.0; // Base back-left

	// Define faces by referring to vertices
	face[0][0] = 0;
	face[0][1] = 1;
	face[0][2] = 2;  // Front face
	face[1][0] = 0;
	face[1][1] = 2;
	face[1][2] = 3;  // Right face
	face[2][0] = 0;
	face[2][1] = 3;
	face[2][2] = 4;  // Back face
	face[3][0] = 0;
	face[3][1] = 4;
	face[3][2] = 1;  // Left face
	face[4][0] = 1;
	face[4][1] = 2;
	face[4][2] = 3;
	face[4][3] = 4; // Base (quad)
}

void Pyramid::drawFace(int i) {
	if (i < 4) {
		glBegin (GL_TRIANGLES);  // Faces from apex to base vertices
		glVertex3fv (vertex[face[i][0]]);
		glVertex3fv(vertex[face[i][1]]);
		glVertex3fv(vertex[face[i][2]]);
		glEnd();
	} else if (i == 4) {
		glBegin (GL_QUADS);  // Base face
		glVertex3fv (vertex[face[i][0]]);
		glVertex3fv(vertex[face[i][1]]);
		glVertex3fv(vertex[face[i][2]]);
		glVertex3fv(vertex[face[i][3]]);
		glEnd();
	}
}

void Pyramid::draw() {
	glPushMatrix();
	this->ctmMultiply();       // Apply transformations
	glColor3f(0.0, 1.0, 0.0);  // Green color for visibility

	for (int i = 0; i < 5; i++) {
		drawFace(i);  // Draw each face
	}
	glPopMatrix();
}
