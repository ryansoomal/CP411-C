#include "Cube.hpp"

Cube::Cube() {
	// set set cordinate values for all vertices
	// other faces
	r = 1.0;
	g = 1.0;
	b = 1.0;

	// Define vertices
	vertex[0][0] = -1;
	vertex[0][1] = -1;
	vertex[0][2] = -1;
	vertex[1][0] = 1;
	vertex[1][1] = -1;
	vertex[1][2] = -1;
	// ... (define other vertices)

	// Define faces using vertex indices
	face[0][0] = 0;
	face[0][1] = 1;
	face[0][2] = 2;
	face[0][3] = 3; // etc.
}

void Cube::drawFace(int i) {
	glBegin(GL_QUADS);
	glVertex3fv(vertex[face[i][0]]);
	glVertex3fv(vertex[face[i][1]]);
	glVertex3fv(vertex[face[i][2]]);
	glVertex3fv(vertex[face[i][3]]);
	glEnd();
}

void Cube::draw() {
	glPushMatrix();
	this->ctmMultiply();
	// set color
	glColor3f(1.0, 0.0, 0.0); // Red color for visibility
	// draw all faces
	for (int i = 0; i < 6; i++) {
		drawFace(i);
	}
	glPopMatrix();
}

