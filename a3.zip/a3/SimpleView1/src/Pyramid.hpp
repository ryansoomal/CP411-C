/*
 -------------------------------------
 File:    Pyramid.hpp
 Project: SimpleView1_reference_design
 file description
 -------------------------------------
 Author:  Ryan Soomal
 ID:      210370340
 Email:   soom0340@mylaurier.ca
 Version  2024-10-25
 -------------------------------------
 */
#ifndef PYRAMID_HPP
#define PYRAMID_HPP

#include "Shape.hpp"
#include <GL/glut.h>

class Pyramid: public Shape {
protected:
	GLfloat vertex[5][3];  // Array to store the vertices of the pyramid
	GLint face[5][3];      // Array to store the faces using vertex indices

public:
	Pyramid();
	void drawFace(int i);  // Draws a single face of the pyramid
	void draw();           // Draws the pyramid by drawing each face
};

#endif
