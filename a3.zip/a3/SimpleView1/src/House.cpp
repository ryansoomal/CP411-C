/*
 -------------------------------------
 File:    House.cpp
 Project: SimpleView1_reference_design
 file description
 -------------------------------------
 Author:  Ryan Soomal
 ID:      210370340
 Email:   soom0340@mylaurier.ca
 Version  2024-10-25
 -------------------------------------
 */

#include "House.hpp"

House::House() {
	// Initialize the base and roof
	base = new Cube();
	base->setParentMC(&mc);  // Set the model coordinate for Cube to House’s MC

	roof = new Pyramid();
	roof->setParentMC(&mc); // Set the model coordinate for Pyramid to House’s MC
	roof->translate(0.0, 1.0, 0.0);  // Move the roof to the top of the base
}

House::~House() {
	delete base;  // Clean up dynamically allocated Cube and Pyramid objects
	delete roof;
}

void House::draw() {
	glPushMatrix();
	this->ctmMultiply();  // Apply current transformation matrix

	base->draw();  // Draw the base (cube)
	roof->draw();  // Draw the roof (pyramid)

	glPopMatrix();
}
