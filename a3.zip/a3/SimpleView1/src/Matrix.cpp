#include "Matrix.hpp"
#include <stdio.h>
#include <math.h>
#include <iostream>

using namespace std;

Matrix::Matrix() {
	loadIdentity();
}

// mat <- identity matrix
void Matrix::loadIdentity() {
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			if (i == j)
				mat[i][j] = 1;
			else
				mat[i][j] = 0;
		}
	}
}

// multiplication  mat <- m * mat
void Matrix::matrixPreMultiply(Matrix *m) {
	GLfloat temp[4][4];

	// Perform matrix multiplication: temp = m * this->mat
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			temp[i][j] = 0;
			for (int k = 0; k < 4; k++) {
				temp[i][j] += m->mat[i][k] * this->mat[k][j];
			}
		}
	}

	// Copy the result back to this->mat
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			this->mat[i][j] = temp[i][j];
		}
	}
}

// transpose  mat <- mat'
void Matrix::transpose() {
	for (int i = 0; i < 4; i++) {
		for (int j = i + 1; j < 4; j++) {
			GLfloat temp = mat[i][j];
			mat[i][j] = mat[j][i];
			mat[j][i] = temp;
		}
	}
}

// normalize MC
void Matrix::normalize() {
	for (int i = 0; i < 3; i++) {
		GLfloat length = sqrt(
				mat[i][0] * mat[i][0] + mat[i][1] * mat[i][1]
						+ mat[i][2] * mat[i][2]);
		for (int j = 0; j < 3; j++) {
			mat[i][j] /= length;
		}
	}
}

// v  <- mat * v
void Matrix::multiplyVector(GLfloat *v) {
	GLfloat result[4];
	for (int i = 0; i < 4; i++) {
		result[i] = 0;
		for (int j = 0; j < 4; j++) {
			result[i] += mat[i][j] * v[j];
		}
	}
	for (int i = 0; i < 4; i++) {
		v[i] = result[i];
	}
}

void Matrix::rotateMatrix(GLfloat rx, GLfloat ry, GLfloat rz, GLfloat angle) {
	GLfloat rad = angle * M_PI / 180.0;
	GLfloat c = cos(rad);
	GLfloat s = sin(rad);
	GLfloat t = 1 - c;

	mat[0][0] = t * rx * rx + c;
	mat[0][1] = t * rx * ry - s * rz;
	mat[0][2] = t * rx * rz + s * ry;
	mat[1][0] = t * rx * ry + s * rz;
	mat[1][1] = t * ry * ry + c;
	mat[1][2] = t * ry * rz - s * rx;
	mat[2][0] = t * rx * rz - s * ry;
	mat[2][1] = t * ry * rz + s * rx;
	mat[2][2] = t * rz * rz + c;
}

