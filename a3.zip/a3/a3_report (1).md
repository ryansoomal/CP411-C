# A3 Report

Author: Ryan Soomal

Date: 2024-10-25

Check [readme.txt](readme.txt) for course work statement and self-evaluation. 
  
## Q1 Transformations in CG (description)


### Q1.1 Principle of CG transformations

The three basic transformations in computer graphics are translation, rotation, and scaling. Translation moves an object from one position to another, rotation turns it around a specific axis, and scaling changes its size.

### Q1.2 Hand on 2D transformations

What is a composite transformation?

A composite transformation combines multiple transformations (like translation, rotation, and scaling) into a single operation. This allows complex transformations to be applied efficiently and consistently, as each step is combined into one transformation matrix.

Why is the Homogeneous coordinate system used in transformation representation and computing?

The Homogeneous coordinate system simplifies calculations for transformations by allowing all transformations (translation, rotation, scaling) to be represented as matrix multiplications. This system also makes it easy to combine multiple transformations into a single matrix, streamlining the computation and representation of complex transformations in graphics.

## Q2 CG transformation programming (lab practice)


### Q2.1 Warm up with C++ 

Complete? Yes or No 

<!--If you answer Yes, insert one or more screenshot images to show the completion.-->

![alt text](<images/image (8).png>)


<!-- If No, add a short description to describe the issues encountered.-->

### Q2.2 2D transformations 

Complete? Yes or No 

<!--If you answer Yes, insert one or more screenshot images to show the completion.-->

![Image caption](<images/image (6).png>){width=90%}

<!-- If No, add a short description to describe the issues encountered.-->

### Q2.3 3D objects and transformations 

Complete? Yes or No 

<!--If you answer Yes, insert one or more screenshot images to show the completion.-->

![Image caption](<images/image (7).png>){width=90%}

<!-- If No, add a short description to describe the issues encountered.-->

### Q2.4 Mesh object model 

Complete? Yes or No 

<!--If you answer Yes, insert one or more screenshot images to show the completion.-->

![Image caption](<images/image (9).png>){width=90%}

<!-- If No, add a short description to describe the issues encountered.-->


## Q3 SimpleView1 - transformations (programming)


### Q3.1 Create and render cube objects

Complete? Yes or No 

<!--If you answer Yes, insert one or more screenshot images to show the completion. -->

![Image caption](<images/image (10).png>){width=90%}

<!--If No, add a short description to describe the issues encountered.-->


### Q3.2 Create and render pyramid object

Complete? Yes or No 

<!--If you answer Yes, insert one or more screenshot images to show the completion. -->

![Image caption](<images/image (10).png>){width=90%}

<!--If No, add a short description to describe the issues encountered.-->


### Q3.3 Create and render house object

Complete? Yes or No 

<!--If you answer Yes, insert one or more screenshot images to show the completion. -->

![Image caption](<images/image (10).png>){width=90%}

<!--If No, add a short description to describe the issues encountered.-->


### Q3.4 MCS transforms

Complete? Yes or No 

<!--If you answer Yes, insert one or more screenshot images to show the completion. -->

![Image caption](<images/image (11).png>){width=90%}

<!--If No, add a short description to describe the issues encountered.-->


### Q3.5 WCS transforms

Complete? Yes or No 

<!--If you answer Yes, insert one or more screenshot images to show the completion. -->

![Image caption](<images/image (12).png>){width=90%}

<!--If No, add a short description to describe the issues encountered.-->


### Q3.6 VCS transforms

Complete? Yes or No 

<!--If you answer Yes, insert one or more screenshot images to show the completion. -->

![Image caption](<images/image (13).png>){width=90%}

<!--If No, add a short description to describe the issues encountered.-->




**References**

1. CP411 a3
2. Add your references if you used any. 
