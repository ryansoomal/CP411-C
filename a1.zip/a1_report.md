# A1 Report

Author: Ryan Soomal

Date: 2024-09-17 

Check [readme.txt](readme.txt) for course work statement and self-evaluation. 
  
## Q1 Concepts of raster display systems (short answer)


### Q1.1 framebuffers

Framebuffers are memory buffers that hold the image data displayed on the screen. They store the color information for each pixel, allowing the display to render the image as a whole.


### Q1.2 pixels, color depth, and resolution

Pixels: The smallest units of an image on a screen. Each pixel represents a point in the image and combines to form the complete picture.
Color Depth: Refers to the number of bits used to represent the color of each pixel. Higher color depth allows for more colors and finer gradations of color.
Resolution: The number of pixels displayed on the screen, usually given as width × height (e.g., 1920 × 1080). Higher resolution means more detail and clarity.


### Q1.3 Frame, refreshment, and refresh rate

Frame: A single image in a sequence of images displayed on the screen.
Refreshment: The process of updating the displayed image on the screen from the framebuffer.
Refresh Rate: The number of times the screen is updated per second, measured in Hertz (Hz). A higher refresh rate results in smoother motion and less flicker.



## Q2 Concepts of image rendering (short answer)
Image rendering is the process of generating a visual representation of a scene from a set of data. It involves converting a 3D model or scene into a 2D image on the screen, including calculations for lighting, shading, and color.

### Q2.1 What are the two basic image rendering approaches?

Rasterization: Converts 3D models into 2D images by determining which pixels should be lit to represent objects. It is efficient for real-time graphics.
Ray Tracing: Simulates the way light interacts with objects by tracing rays from the eye or camera into the scene. It produces highly realistic images but is computationally intensive.


### Q2.2 Why rasterization is commonly used in graphics applications?

Rasterization is commonly used because it is faster and more efficient for rendering real-time graphics, such as in video games. It converts 3D scenes into 2D images quickly, making it suitable for applications requiring high frame rates.



## Q3 Roles of CPU and GPU in CG (short answer)


### Q3.1 CPU roles

The CPU (Central Processing Unit) handles general-purpose computations and is responsible for managing tasks such as game logic, physics calculations, and overall control of the graphics pipeline. It prepares data and instructions for the GPU to process.


### Q3.2 GPU roles

The GPU (Graphics Processing Unit) specializes in rendering images and processing large amounts of visual data. It handles tasks such as shading, texture mapping, and pixel processing, allowing for high-performance graphics and parallel processing of image data.



## Q4 C/C++ OpenGL programming environment (lab practice)


### Q4.1 C/C++ OpenGL installation 

Complete? Yes or No 

<!--If you answer Yes, insert a screenshot image to show the completion.-->

![Image caption](images/demo.png){width=90%}

<!-- If No, add a short description to describe the issues encountered.-->

### Q4.2 OpenGL C project 

Complete? Yes or No 

<!--If you answer Yes, insert a screenshot image to show the completion.-->

![Image caption](images/demo.png){width=90%}

<!-- If No, add a short description to describe the issues encountered.-->

### Q4.3 OpenGL C++ project 

Complete? Yes or No 

<!--If you answer Yes, insert a screenshot image to show the completion.-->

![Image caption](images/demo.png){width=90%}

<!-- If No, add a short description to describe the issues encountered.-->



**References**

1. CP411 a1
2. Add your references if you used any. 
