# A2 Report

Author: Ryan Soomal

Date: 2024-10-01 

Check [readme.txt](readme.txt) for course work statement and self-evaluation. 
  
## Q1 Graphics pipeline (description)


### Q1.1 Graphics primitives

Graphics primitives are the most basic elements used to create graphical images. They are fundamental building blocks from which more complex graphics objects are formed. Examples of graphics primitives include:

Points: Single pixel or location in space.
Lines: Straight connections between two points.
Triangles, Rectangles, and Polygons: Shapes composed of multiple connected points.
Curves: Smooth, continuous paths defined mathematically.
Relationship to Graphics Objects: Graphics objects are composed of these primitives. For example, a complex 3D model of a car is made up of triangles (a primitive). By combining and transforming these primitives, more detailed and intricate objects can be represented.

### Q1.2 Graphics pipeline operations

The graphics pipeline refers to the process through which 3D models are converted into 2D images. The major stages in this pipeline include:

Vertex Processing: Transforms 3D vertices into 2D screen space coordinates, applying projection, lighting, and shading calculations.
Clipping: Ensures that only visible parts of the scene are rendered.
Rasterization: Converts geometric data (primitives like triangles) into pixels on the screen.
Fragment Processing: Computes color and other attributes for each pixel.
Output Merging: Combines the pixels into the final image.


### Q1.3 Coordinate systems & transformations

In graphics, several coordinate systems are used to represent objects at different stages of the pipeline:

Model Coordinates: Local coordinates of an object.
World Coordinates: Global scene coordinates after placing objects in the scene.
View Coordinates: Coordinates relative to the camera's point of view.
Clip Coordinates: Transformed coordinates ready for clipping.
Screen Coordinates: Final pixel locations on the display.
Transformations:

Translation: Moving an object in space.
Scaling: Resizing an object.
Rotation: Rotating an object around an axis.
Projection: Mapping 3D coordinates to a 2D screen.


### Q1.4 Scan conversion

A scan conversion algorithm is responsible for converting the mathematical descriptions of graphics primitives (like lines or circles) into pixels on the screen. It involves determining which pixels correspond to the primitive and coloring them. For instance, for a line, the algorithm calculates which pixels the line passes through and sets them.


### Q1.5 Hand-on Midpoint algorithm

x	
𝑦
y	Decision Parameter (P)
0	10	
𝑃
=
−
9
P=−9
1	10	
𝑃
=
−
6
P=−6
2	10	
𝑃
=
−
1
P=−1
3	10	
𝑃
=
6
P=6
4	9	
𝑃
=
−
3
P=−3
5	9	
𝑃
=
8
P=8
6	8	
𝑃
=
5
P=5

Write you answer on paper, write your name on the paper, take a picture and save it in the image folder, and link as follows.  

![Image caption](images/a2q1_5.jpg){width=90%}
![alt text](a2_q1_5-1.png)

## Q2 OpenGL and Glut (lab practice)


### Q2.1 OpenGL primitives 

Complete? Yes or No 

<!--If you answer Yes, insert a screenshot image to show the completion.-->
YES
![Image caption](images/demo.png){width=90%}
![alt text](a2q2_1_demo-1.png)

<!-- If No, add a short description to describe the issues encountered.-->

### Q2.2 Interactive graphics 

Complete? Yes or No 
YES

<!--If you answer Yes, insert a screenshot image to show the completion.-->
![alt text](a2q2_2a_demo-1.png)
![alt text](a2q2_2b_demo-1.png)
![alt text](a2q2_2c_demo-1.png)
![alt text](a2q2_2d_demo-1.png)

![Image caption](images/demo.png){width=90%}

<!-- If No, add a short description to describe the issues encountered.-->

### Q2.3 Bitmap file I/O 

Complete? Yes or No 
YES
<!--If you answer Yes, insert a screenshot image to show the completion.-->

![Image caption](images/demo.png){width=90%}
![alt text](a2q2_3_demo-1.png)

<!-- If No, add a short description to describe the issues encountered.-->


## Q3 SimpleDraw (programming)


### Q3.1 Display window and menu

Complete? Yes or No 
YES
<!--If you answer Yes, insert a screenshot image to show the completion. -->

![Image caption](images/demo.png){width=90%}

![alt text](simpledraw-1.png)
<!--If No, add a short description to describe the issues encountered.-->


### Q3.2 Data structures

Complete? Yes or No 

<!--If you answer Yes, insert a screenshot image to show the completion. -->
YES
![Image caption](images/demo.png){width=90%}
![alt text](simpledraw-2.png)

<!--If No, add a short description to describe the issues encountered.-->


### Q3.3 Draw rectangles

Complete? Yes or No 

<!--If you answer Yes, insert a screenshot image to show the completion. -->
YES
![Image caption](images/demo.png){width=90%}
![alt text](simpledraw-3.png)

<!--If No, add a short description to describe the issues encountered.-->


### Q3.4 Draw circles

Complete? Yes or No 
YES

<!--If you answer Yes, insert a screenshot image to show the completion. -->

![Image caption](images/demo.png){width=90%}
![alt text](simpledraw-4.png)

<!--If No, add a short description to describe the issues encountered.-->


### Q3.5 Edit features

Complete? Yes or No 
YES
<!--If you answer Yes, insert a screenshot image to show the completion. -->

![Image caption](images/demo.png){width=90%}
![alt text](simpledraw-5.png)

<!--If No, add a short description to describe the issues encountered.-->


### Q3.6 Save/Open SVG files

Complete? Yes or No

If you answer Yes, link the image
![output.bmp](images/output.svg).
YES ![alt text](simpledraw-6.png)

### Q3.7 Export to bitmap

Complete? Yes or No

If you answer Yes, link the image
![ouput.bmp](images/output.bmp).
![alt text](simpledraw-7.png)

### Q3.8 Circle&Square artwork

Complete? Yes or No

If you answer Yes, link the images
[C&S artwork in SVG](images/c&s.svg)
![C&S artwork in bitmap](images/c&s.bmp).




**References**

1. CP411 a2
2. Add your references if you used any. 
