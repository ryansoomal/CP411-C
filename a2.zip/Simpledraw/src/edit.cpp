/*
 * Description: implementation of edit.hpp
 * Author: HBF
 * Version: 2021-08-24
 */

#include <stdio.h>
#include <GL/glut.h>
#include <math.h>
#include "object.hpp"

extern LIST objlist;

GLint min(GLint x, GLint y) {
	return x < y ? x : y;
}

GLint max(GLint x, GLint y) {
	if (x < y)
		return y;
	else
		return x;
}

NODE *select(GLint x, GLint y) {
	// your implementation
    // search the object that cover the clicking point staring
    NODE *p = objlist.head;
    while (p) {
        SHAPE *obj = p->shape;
        if (obj->type == RECTANGLE) {
            if (x >= obj->x1 && x <= obj->x2 && y >= obj->y1 && y <= obj->y2) {
                return p; // Object found
            }
        } else if (obj->type == CIRCLE) {
            GLfloat centerX = obj->x1;
            GLfloat centerY = obj->y1;
            GLfloat radius = obj->radius;
            if (sqrt(pow(x - centerX, 2) + pow(y - centerY, 2)) <= radius) {
                return p; // Object found
            }
        }
        p = p->next;
    }
	return NULL;
}

void Delete(NODE **pp) {
    if (*pp == NULL) return; // Nothing to delete
    NODE *temp = *pp;
    *pp = (*pp)->next; // Move to next node
    free(temp->shape); // Free the shape object
    free(temp); // Free the node
}


void moveBack(NODE **head, NODE *selectedNode) {
    if (selectedNode == NULL || selectedNode == *head) {
        // Can't move back if it's NULL or already at the back
        return;
    }

    // Find the previous node
    NODE *prev = *head;
    while (prev->next != NULL && prev->next != selectedNode) {
        prev = prev->next;
    }

    // If we found the previous node, we can perform the move
    if (prev->next == selectedNode) {
        // Adjust pointers to move the selected node back
        prev->next = selectedNode->next; // Remove selected from its position
        selectedNode->next = prev; // Move selected node back
        // If selected node was not the second node, connect to its previous node
        if (prev != *head) {
            NODE *beforePrev = *head;
            while (beforePrev->next != prev) {
                beforePrev = beforePrev->next;
            }
            beforePrev->next = selectedNode; // Link the previous node to selected
        } else {
            // If selected is the first node, update head
            *head = selectedNode; // Update head to selected node
        }
    }
}

// Move selected object front in drawing order
void moveFront(NODE **head, NODE *selectedNode) {
    if (selectedNode == NULL || selectedNode->next == NULL) {
        // Can't move front if it's NULL or already at the front
        return;
    }

    // Find the previous node
    NODE *prev = *head;
    while (prev->next != NULL && prev->next != selectedNode) {
        prev = prev->next;
    }

    // If we found the previous node, we can perform the move
    if (prev->next == selectedNode) {
        // Remove selected node from its current position
        prev->next = selectedNode->next;

        // Move selected node to the front
        selectedNode->next = *head; // Set its next to current head
        *head = selectedNode; // Update head to the selected node
    }
}

