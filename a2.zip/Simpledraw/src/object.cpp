/*
 * Description: implementation of object.hpp
 * Author: HBF
 * Version: 2021-08-24
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "object.hpp"

void insert(LIST *list, SHAPE *object) {
 NODE *newNode = (NODE *)malloc(sizeof(NODE));  // Allocate memory for a new node
    if (newNode == NULL) {
        printf("Memory allocation failed\n");
        return;
    }

    newNode->shape = object;        // Assign the shape to the new node
    newNode->next = list->head;     // Point to the previous head (existing list)
    list->head = newNode;           // Update head to the new node
}

void deleteNode(LIST *list, NODE **selectp) {
	NODE *toDelete = *selectp;
    
    // If the node to delete is the head node
    if (toDelete == list->head) {
        list->head = toDelete->next; // Update head to the next node
    } else {
        NODE *current = list->head;
        while (current != NULL && current->next != toDelete) {
            current = current->next;
        }
        if (current != NULL) {
            current->next = toDelete->next; // Bypass the node to delete
        }
    }

    free(toDelete->shape);  // Free shape object if dynamically allocated
    free(toDelete);         // Free the node
    *selectp = NULL;        // Set the pointer to NULL
}


void clearList(LIST *list) {
  NODE *current = list->head;
    NODE *nextNode;

    while (current != NULL) {
        nextNode = current->next;    // Store next node
        free(current->shape);        // Free the shape object
        free(current);               // Free the current node
        current = nextNode;          // Move to the next node
    }

    list->head = NULL;               // List is now empty
}

void drawShape(SHAPE *object) {
    if (object->type == RECTANGLE) {  // rectangle
        glBegin(GL_QUADS);
        glColor3f(object->fr, object->fg, object->fb); // Use object here
        glVertex2f(object->x1, object->y1);
        glVertex2f(object->x2, object->y1);
        glVertex2f(object->x2, object->y2);
        glVertex2f(object->x1, object->y2);
        glEnd();
        
    } else if (object->type == CIRCLE) {  // circle
        glBegin(GL_TRIANGLE_FAN);
        glColor3f(object->fr, object->fg, object->fb); // Use object here
        glVertex2f(object->x1, object->y1); // Center
        for (int i = 0; i <= 360; i++) {
            float angle = i * (3.14159f / 180.0f);
            glVertex2f(object->x1 + cos(angle) * object->x2, object->y1 + sin(angle) * object->x2); // Radius is x2
        }
        glEnd();
    }
        glFlush();  // Ensure the shape is drawn properly
}

void drawShapeHighLight(SHAPE *object) {
    glLineWidth(object->swidth); // Set the stroke width
    glColor3f(1.0f, 0.0f, 0.0f);  // Set highlight color (red in this case)
    
    if (object->type == RECTANGLE) {  // If the shape is a rectangle
        glBegin(GL_LINE_LOOP); // Draw a line loop for the outline
        glVertex2f(object->x1, object->y1);
        glVertex2f(object->x2, object->y1);
        glVertex2f(object->x2, object->y2);
        glVertex2f(object->x1, object->y2);
        glEnd();
        
    } else if (object->type == CIRCLE) {  // If the shape is a circle
        glBegin(GL_LINE_LOOP); // Draw a line loop for the outline
        for (int i = 0; i <= 360; i++) {
            float angle = i * (3.14159f / 180.0f);
            glVertex2f(object->x1 + cos(angle) * object->x2, object->y1 + sin(angle) * object->x2); // Radius is x2
        }
        glEnd();
    }
}
void drawList(LIST *list) {
	NODE *p = list->head;
	while (p) {
		drawShape(p->shape);
		p = p->next;
	}
}

void setPixel(GLint x, GLint y) {
	glPointSize(2.0);
	glBegin(GL_POINTS);
	glVertex2i(x, y);
	glEnd();
}

// draw points on line of circle
void circlePlotPoints(const GLint& xc, const GLint& yc, const GLint& x,
		const GLint& y) {
// ...
}

// draw circle main function
void circleMidpoint(GLint x1, GLint y1, GLint x2, GLint y2) {
	// ...
}

void circlePlotPointsFill(GLint x1, GLint y1, GLint x, GLint y) {
	// ...
}

void circleMidpointFill(GLint x1, GLint y1, GLint x2, GLint y2) {
	// ...
}
