/*
 * Description: implementation of SimpleDraw file functions
 * Author: HBF
 * Version: 2021-08-24
 */

#include <GL/glut.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>


#include "file.hpp"
#include "object.hpp"

#define MaxNumObj 100
#define GL_BGR_EXT 0x80E0
#define GL_BGR     0x80E0
#define GL_BGRA    0x80E1
#define MAX_SHAPES 100  // Replace 100 with the maximum number of shapes you want to allow

SHAPE shapes[MAX_SHAPES]; // Declare an array to hold shapes
int shapeCount = 0; // Variable to track the number of shapes added
extern LIST objlist;

int saveBitmap(const char *ptrcFileName, int nX, int nY, int nWidth,
		int nHeight) {
 // Allocate memory for the pixel data
    unsigned char* pixels = (unsigned char*)malloc(3 * nWidth * nHeight);
    if (pixels == NULL) {
        fprintf(stderr, "Failed to allocate memory for pixel data\n");
        return 0; // Indicate failure
    }

    // Read the pixels from the framebuffer
    glReadPixels(nX, nY, nWidth, nHeight, GL_RGB, GL_UNSIGNED_BYTE, pixels);

    // BMP file header
    FILE* file = fopen(ptrcFileName, "wb");
    if (file == NULL) {
        fprintf(stderr, "Could not open file for writing\n");
        free(pixels);
        return 0; // Indicate failure
    }

    // BMP Header
    unsigned char bmpHeader[54] = {
        'B', 'M',                 // BMP file signature
        0, 0, 0, 0,              // Image file size in bytes (placeholder)
        0, 0,                     // Reserved 1
        0, 0,                     // Reserved 2
        54, 0, 0, 0,             // Start of pixel array
        40, 0, 0, 0,             // Header size
        0, 0, 0, 0,              // Image width (placeholder)
        0, 0, 0, 0,              // Image height (placeholder)
        1, 0,                     // Number of color planes
        24, 0,                    // Bits per pixel
        0, 0, 0, 0,              // Compression (none)
        0, 0, 0, 0,              // Image size (can be 0 for uncompressed)
        0, 0, 0, 0,              // Horizontal resolution (pixels per meter)
        0, 0, 0, 0,              // Vertical resolution (pixels per meter)
        0, 0, 0, 0,              // Number of colors in the palette (0 for 2^24)
        0, 0, 0, 0               // Number of important colors (0 means all)
    };

    // Fill in the image size and dimensions
    int imageSize = 3 * nWidth * nHeight;
    int fileSize = 54 + imageSize;

    bmpHeader[2] = (unsigned char)(fileSize);
    bmpHeader[3] = (unsigned char)(fileSize >> 8);
    bmpHeader[4] = (unsigned char)(fileSize >> 16);
    bmpHeader[5] = (unsigned char)(fileSize >> 24);

    bmpHeader[18] = (unsigned char)(nWidth);
    bmpHeader[19] = (unsigned char)(nWidth >> 8);
    bmpHeader[20] = (unsigned char)(nWidth >> 16);
    bmpHeader[21] = (unsigned char)(nWidth >> 24);

    bmpHeader[22] = (unsigned char)(nHeight);
    bmpHeader[23] = (unsigned char)(nHeight >> 8);
    bmpHeader[24] = (unsigned char)(nHeight >> 16);
    bmpHeader[25] = (unsigned char)(nHeight >> 24);

    // Write the header to the file
    fwrite(bmpHeader, sizeof(unsigned char), 54, file);

    // Write the pixel data to the file
    for (int i = 0; i < nHeight; i++) {
        fwrite(pixels + (nWidth * 3 * (nHeight - i - 1)), sizeof(unsigned char), nWidth * 3, file);
    }

    // Clean up
    fclose(file);
    free(pixels);
    return 1; // Indicate success
}

int saveSVG(const char *filename, int winWidth, int winHeight) {
	 FILE *fp = fopen(filename, "w");
    if (fp == NULL) return EXIT_FAILURE;

    char line[255];
    // Write SVG header (your existing code)
    // ...

    // Loop through shapes
    for (int i = 0; i < shapeCount; i++) { // Use shapeCount to avoid accessing uninitialized shapes
        SHAPE currentShape = shapes[i]; // Assuming shapes is defined globally

        int height; // Declare height outside of switch to avoid jump error
        switch (currentShape.type) {
            case RECTANGLE:
                height = abs(currentShape.y2 - currentShape.y1); // Calculate height
                fprintf(fp, "<rect x=\"%d\" y=\"%d\" width=\"%d\" height=\"%d\" fill=\"rgb(%f,%f,%f)\" stroke=\"rgb(%f,%f,%f)\" stroke-width=\"%d\"/>\n",
                        currentShape.x1, currentShape.y1, abs(currentShape.x2 - currentShape.x1), height,
                        currentShape.fr, currentShape.fg, currentShape.fb,
                        currentShape.sr, currentShape.sg, currentShape.sb,
                        currentShape.swidth);
                break;

            case CIRCLE:
                GLfloat radius = abs(currentShape.x2 - currentShape.x1); // Example radius calculation
                fprintf(fp, "<circle cx=\"%d\" cy=\"%d\" r=\"%f\" fill=\"rgb(%f,%f,%f)\" stroke=\"rgb(%f,%f,%f)\" stroke-width=\"%d\"/>\n",
                        currentShape.x1, currentShape.y1, radius,
                        currentShape.fr, currentShape.fg, currentShape.fb,
                        currentShape.sr, currentShape.sg, currentShape.sb,
                        currentShape.swidth);
                break;

            // Handle other shape types...
        }
    }

    sprintf(line, "</svg>\n");
    fputs(line, fp);
    fclose(fp);

    return EXIT_SUCCESS;
}

int openSVG(const char *filename) {
	FILE* fp = fopen(filename, "r");
	if (fp == NULL) return EXIT_FAILURE;

	int lineLength = 255;
	char line[lineLength];
	int x1, y1, w, h, fr, fg, fb, sr, sg, sb, sw; // variables to hold scan values

	// read line by line, if it is line of rect/circle element, retrieve the attribute values and convert them to
	// object values and create object and insert to the object list.

	while ( fgets(line, lineLength, fp)) {
		//printf("%s\n", buffer);
		SHAPE *shapeObj;
		if (line[0] == '<' && line[1] == 'r' ) { // rectangle
			sscanf(line,
					"<rect x=\"%d\" y=\"%d\" width=\"%d\" height=\"%d\" fill=\"rgb(%d,%d,%d)\" stroke=\"rgb(%d,%d,%d)\" stroke-width=\"%d\"/>",
					&x1, &y1, &w, &h, &fr, &fg, &fb, &sr, &sg, &sb, &sw);

			shapeObj = (SHAPE*) malloc(sizeof(SHAPE));
			shapeObj->type = RECTANGLE;
			shapeObj->x1 = x1;
			shapeObj->y1 = y1;
			shapeObj->x2 = x1 + w;
			shapeObj->y2 = y1 + h;
			shapeObj->fr = fr / 255;
			shapeObj->fg = fg / 255;
			shapeObj->fb = fb / 255;
			shapeObj->sr = sr / 255;
			shapeObj->sg = sg / 255;
			shapeObj->sb = sb / 255;
			shapeObj->swidth = sw;
			insert(&objlist, shapeObj);

		} else if (line[0] == '<' && line[1] == 'c' )  {
			int cx, cy, radius, fr, fg, fb, sr, sg, sb, sw;
    sscanf(line,
        "<circle cx=\"%d\" cy=\"%d\" r=\"%d\" fill=\"rgb(%d,%d,%d)\" stroke=\"rgb(%d,%d,%d)\" stroke-width=\"%d\"/>",
        &cx, &cy, &radius, &fr, &fg, &fb, &sr, &sg, &sb, &sw);

    shapeObj = (SHAPE*) malloc(sizeof(SHAPE));
    shapeObj->type = CIRCLE;
    shapeObj->x1 = cx; // center x
    shapeObj->y1 = cy; // center y
    shapeObj->radius = radius; // set radius
    shapeObj->fr = fr / 255;
    shapeObj->fg = fg / 255;
    shapeObj->fb = fb / 255;
    shapeObj->sr = sr / 255;
    shapeObj->sg = sg / 255;
    shapeObj->sb = sb / 255;
    shapeObj->swidth = sw;
    insert(&objlist, shapeObj);
		}
	}

	fclose(fp);

	return EXIT_SUCCESS;
}

